# ⚡ Marvel Suits Mod — Minecraft 1.21.11 (Fabric)

Adds 5 Marvel superhero suits and the legendary **Infinity Gauntlet** to Minecraft, each hidden inside rare generated structures.

---

## 🦸 Suits & Set Bonuses

When you wear the **full 4-piece suit**, you get powerful effects:

| Suit | Set Bonus |
|------|-----------|
| 🔴 **Iron Man** | Fire Resistance, Speed II, Strength II |
| 🕷️ **Spider-Man** | Speed III, Jump Boost III, Slow Falling |
| ⚡ **Thor** | Strength III, Resistance II, Speed I |
| 🐾 **Black Panther** | Speed III, Strength II, Night Vision |
| 🛡️ **Captain America** | Resistance II, Regeneration II, Strength I |
| 💎 **Infinity Gauntlet** | ALL effects at max level (godlike) |

---

## 🏛️ Structures

Each suit spawns in its own rare overworld structure:

- **Iron Man Vault** — Found on the surface (~1 per 200 chunks)
- **Spider-Man Vault** — Found on the surface (~1 per 250 chunks)
- **Thor Vault** — Found on the surface (~1 per 300 chunks)
- **Black Panther Vault** — Found on the surface (~1 per 300 chunks)
- **Captain America Vault** — Found on the surface (~1 per 350 chunks)
- **Infinity Vault** — Underground, extremely rare (~1 per 500 chunks spacing, **1% chance** the chest contains the Gauntlet)

---

## 🔧 Setup & Build

### Requirements
- Java 21
- Gradle 8+
- Fabric Loader 0.18.1
- Fabric API 0.119.5+1.21.11

### Build
```bash
./gradlew build
```

The `.jar` file will appear in `build/libs/`.

### Install
1. Install [Fabric Loader 0.18.1](https://fabricmc.net/use/installer/) for Minecraft 1.21.11
2. Download [Fabric API](https://modrinth.com/mod/fabric-api) for 1.21.11
3. Drop both `.jar` files into your `.minecraft/mods/` folder
4. Launch the game!

---

## 🎨 Adding Textures

The mod includes placeholder item models. To add custom textures:

1. Create 16x16 PNG images for each item
2. Place them in:
   ```
   src/main/resources/assets/marvelmod/textures/item/
   ```
   Named like: `iron_man_helmet.png`, `spider_man_chestplate.png`, etc.

For **3D armor models**, you'll need to add armor texture layers in:
```
src/main/resources/assets/marvelmod/textures/models/armor/
```
Named `iron_man_layer_1.png` and `iron_man_layer_2.png` (legs use layer 2).

---

## 📁 Project Structure

```
marvel-suits-mod/
├── build.gradle
├── gradle.properties
├── settings.gradle
└── src/main/
    ├── java/com/marvelmod/
    │   ├── MarvelMod.java              ← Main entrypoint
    │   ├── armor/
    │   │   ├── MarvelArmorItem.java    ← Set bonus logic
    │   │   └── MarvelArmorMaterials.java ← Armor stats
    │   ├── item/
    │   │   └── MarvelItems.java        ← Item registration
    │   └── structure/
    │       └── MarvelStructureGenerator.java
    └── resources/
        ├── fabric.mod.json
        ├── assets/marvelmod/
        │   ├── lang/en_us.json
        │   └── models/item/            ← 24 item models
        └── data/marvelmod/
            ├── loot_tables/chests/     ← 6 loot tables (1% gauntlet!)
            └── worldgen/
                ├── structure/          ← 6 structure definitions
                └── structure_set/      ← 6 placement configs
```

---

## ⚠️ Notes

- Textures are **not included** — you need to add your own PNG files or use a resource pack
- Structure NBT files (the actual room layouts) need to be built in-game using structure blocks, then exported to `data/marvelmod/structures/`
- The Infinity Gauntlet has a **~1% chance** per chest roll — it's intentionally very hard to find!
