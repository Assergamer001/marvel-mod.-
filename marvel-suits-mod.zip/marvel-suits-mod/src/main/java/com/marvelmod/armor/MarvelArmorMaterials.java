package com.marvelmod.armor;

import com.marvelmod.MarvelMod;
import net.minecraft.item.equipment.ArmorMaterial;
import net.minecraft.item.equipment.EquipmentType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

import java.util.EnumMap;
import java.util.Map;

public class MarvelArmorMaterials {

    public static RegistryEntry<ArmorMaterial> IRON_MAN;
    public static RegistryEntry<ArmorMaterial> SPIDER_MAN;
    public static RegistryEntry<ArmorMaterial> THOR;
    public static RegistryEntry<ArmorMaterial> BLACK_PANTHER;
    public static RegistryEntry<ArmorMaterial> CAPTAIN_AMERICA;
    public static RegistryEntry<ArmorMaterial> INFINITY_GAUNTLET;

    private static RegistryEntry<ArmorMaterial> register(String name, Map<EquipmentType, Integer> defense,
                                                          int enchantability, float toughness, float knockbackResistance) {
        ArmorMaterial material = new ArmorMaterial(
                defense,
                enchantability,
                SoundEvents.ITEM_ARMOR_EQUIP_NETHERITE,
                null,
                toughness,
                knockbackResistance
        );
        return Registry.registerReference(Registries.ARMOR_MATERIAL,
                Identifier.of(MarvelMod.MOD_ID, name), material);
    }

    public static void register() {
        // Iron Man Suit - high protection, heavy
        Map<EquipmentType, Integer> ironManDefense = new EnumMap<>(EquipmentType.class);
        ironManDefense.put(EquipmentType.BOOTS, 5);
        ironManDefense.put(EquipmentType.LEGGINGS, 8);
        ironManDefense.put(EquipmentType.CHESTPLATE, 10);
        ironManDefense.put(EquipmentType.HELMET, 5);
        IRON_MAN = register("iron_man", ironManDefense, 30, 4.0f, 0.3f);

        // Spider-Man Suit - light, agile
        Map<EquipmentType, Integer> spiderManDefense = new EnumMap<>(EquipmentType.class);
        spiderManDefense.put(EquipmentType.BOOTS, 3);
        spiderManDefense.put(EquipmentType.LEGGINGS, 6);
        spiderManDefense.put(EquipmentType.CHESTPLATE, 8);
        spiderManDefense.put(EquipmentType.HELMET, 3);
        SPIDER_MAN = register("spider_man", spiderManDefense, 25, 2.0f, 0.1f);

        // Thor Suit - godly defense
        Map<EquipmentType, Integer> thorDefense = new EnumMap<>(EquipmentType.class);
        thorDefense.put(EquipmentType.BOOTS, 5);
        thorDefense.put(EquipmentType.LEGGINGS, 8);
        thorDefense.put(EquipmentType.CHESTPLATE, 11);
        thorDefense.put(EquipmentType.HELMET, 5);
        THOR = register("thor", thorDefense, 35, 5.0f, 0.4f);

        // Black Panther Suit - balanced
        Map<EquipmentType, Integer> blackPantherDefense = new EnumMap<>(EquipmentType.class);
        blackPantherDefense.put(EquipmentType.BOOTS, 4);
        blackPantherDefense.put(EquipmentType.LEGGINGS, 7);
        blackPantherDefense.put(EquipmentType.CHESTPLATE, 9);
        blackPantherDefense.put(EquipmentType.HELMET, 4);
        BLACK_PANTHER = register("black_panther", blackPantherDefense, 28, 3.5f, 0.2f);

        // Captain America Suit - strong defense, high enchantability
        Map<EquipmentType, Integer> capDefense = new EnumMap<>(EquipmentType.class);
        capDefense.put(EquipmentType.BOOTS, 4);
        capDefense.put(EquipmentType.LEGGINGS, 7);
        capDefense.put(EquipmentType.CHESTPLATE, 9);
        capDefense.put(EquipmentType.HELMET, 4);
        CAPTAIN_AMERICA = register("captain_america", capDefense, 40, 3.0f, 0.25f);

        // Infinity Gauntlet - overpowered, single glove
        Map<EquipmentType, Integer> gauntletDefense = new EnumMap<>(EquipmentType.class);
        gauntletDefense.put(EquipmentType.BOOTS, 6);
        gauntletDefense.put(EquipmentType.LEGGINGS, 10);
        gauntletDefense.put(EquipmentType.CHESTPLATE, 12);
        gauntletDefense.put(EquipmentType.HELMET, 6);
        INFINITY_GAUNTLET = register("infinity_gauntlet", gauntletDefense, 50, 6.0f, 1.0f);
    }
}
