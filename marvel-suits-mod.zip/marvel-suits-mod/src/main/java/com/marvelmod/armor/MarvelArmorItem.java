package com.marvelmod.armor;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.equipment.ArmorMaterial;
import net.minecraft.item.equipment.EquipmentType;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.world.World;

public class MarvelArmorItem extends ArmorItem {

    private final SuitType suitType;

    public enum SuitType {
        IRON_MAN, SPIDER_MAN, THOR, BLACK_PANTHER, CAPTAIN_AMERICA, INFINITY_GAUNTLET
    }

    public MarvelArmorItem(RegistryEntry<ArmorMaterial> material, EquipmentType type, Settings settings, SuitType suitType) {
        super(material, type, settings);
        this.suitType = suitType;
    }

    @Override
    public void inventoryTick(ItemStack stack, World world, net.minecraft.entity.Entity entity, int slot, boolean selected) {
        if (!world.isClient && entity instanceof PlayerEntity player) {
            if (hasFullSuit(player)) {
                applySetBonus(player);
            }
        }
    }

    private boolean hasFullSuit(PlayerEntity player) {
        for (ItemStack armorPiece : player.getArmorItems()) {
            if (!(armorPiece.getItem() instanceof MarvelArmorItem marvelPiece) || marvelPiece.suitType != this.suitType) {
                return false;
            }
        }
        return true;
    }

    private void applySetBonus(PlayerEntity player) {
        switch (suitType) {
            case IRON_MAN -> {
                // Iron Man: Fire immunity + speed + strength
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 40, 0, true, false));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 40, 1, true, false));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 40, 1, true, false));
            }
            case SPIDER_MAN -> {
                // Spider-Man: Speed + jump boost + slow falling
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 40, 2, true, false));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 40, 2, true, false));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 40, 0, true, false));
            }
            case THOR -> {
                // Thor: Strength + resistance + lightning-like effects
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 40, 2, true, false));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 40, 1, true, false));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 40, 0, true, false));
            }
            case BLACK_PANTHER -> {
                // Black Panther: Speed + strength + night vision
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 40, 2, true, false));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 40, 1, true, false));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 240, 0, true, false));
            }
            case CAPTAIN_AMERICA -> {
                // Cap: Resistance + regeneration + strength
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 40, 1, true, false));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 40, 1, true, false));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 40, 0, true, false));
            }
            case INFINITY_GAUNTLET -> {
                // Infinity Gauntlet: ALL effects at high level
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 40, 4, true, false));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 40, 4, true, false));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 40, 3, true, false));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 40, 3, true, false));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 40, 0, true, false));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 40, 3, true, false));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 240, 0, true, false));
            }
        }
    }
}
