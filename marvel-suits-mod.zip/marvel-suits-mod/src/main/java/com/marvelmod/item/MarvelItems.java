package com.marvelmod.item;

import com.marvelmod.MarvelMod;
import com.marvelmod.armor.MarvelArmorItem;
import com.marvelmod.armor.MarvelArmorMaterials;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.equipment.EquipmentType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class MarvelItems {

    // ========== IRON MAN ==========
    public static final Item IRON_MAN_HELMET = register("iron_man_helmet",
            new MarvelArmorItem(MarvelArmorMaterials.IRON_MAN, EquipmentType.HELMET,
                    new Item.Settings().maxCount(1), MarvelArmorItem.SuitType.IRON_MAN));
    public static final Item IRON_MAN_CHESTPLATE = register("iron_man_chestplate",
            new MarvelArmorItem(MarvelArmorMaterials.IRON_MAN, EquipmentType.CHESTPLATE,
                    new Item.Settings().maxCount(1), MarvelArmorItem.SuitType.IRON_MAN));
    public static final Item IRON_MAN_LEGGINGS = register("iron_man_leggings",
            new MarvelArmorItem(MarvelArmorMaterials.IRON_MAN, EquipmentType.LEGGINGS,
                    new Item.Settings().maxCount(1), MarvelArmorItem.SuitType.IRON_MAN));
    public static final Item IRON_MAN_BOOTS = register("iron_man_boots",
            new MarvelArmorItem(MarvelArmorMaterials.IRON_MAN, EquipmentType.BOOTS,
                    new Item.Settings().maxCount(1), MarvelArmorItem.SuitType.IRON_MAN));

    // ========== SPIDER-MAN ==========
    public static final Item SPIDER_MAN_HELMET = register("spider_man_helmet",
            new MarvelArmorItem(MarvelArmorMaterials.SPIDER_MAN, EquipmentType.HELMET,
                    new Item.Settings().maxCount(1), MarvelArmorItem.SuitType.SPIDER_MAN));
    public static final Item SPIDER_MAN_CHESTPLATE = register("spider_man_chestplate",
            new MarvelArmorItem(MarvelArmorMaterials.SPIDER_MAN, EquipmentType.CHESTPLATE,
                    new Item.Settings().maxCount(1), MarvelArmorItem.SuitType.SPIDER_MAN));
    public static final Item SPIDER_MAN_LEGGINGS = register("spider_man_leggings",
            new MarvelArmorItem(MarvelArmorMaterials.SPIDER_MAN, EquipmentType.LEGGINGS,
                    new Item.Settings().maxCount(1), MarvelArmorItem.SuitType.SPIDER_MAN));
    public static final Item SPIDER_MAN_BOOTS = register("spider_man_boots",
            new MarvelArmorItem(MarvelArmorMaterials.SPIDER_MAN, EquipmentType.BOOTS,
                    new Item.Settings().maxCount(1), MarvelArmorItem.SuitType.SPIDER_MAN));

    // ========== THOR ==========
    public static final Item THOR_HELMET = register("thor_helmet",
            new MarvelArmorItem(MarvelArmorMaterials.THOR, EquipmentType.HELMET,
                    new Item.Settings().maxCount(1), MarvelArmorItem.SuitType.THOR));
    public static final Item THOR_CHESTPLATE = register("thor_chestplate",
            new MarvelArmorItem(MarvelArmorMaterials.THOR, EquipmentType.CHESTPLATE,
                    new Item.Settings().maxCount(1), MarvelArmorItem.SuitType.THOR));
    public static final Item THOR_LEGGINGS = register("thor_leggings",
            new MarvelArmorItem(MarvelArmorMaterials.THOR, EquipmentType.LEGGINGS,
                    new Item.Settings().maxCount(1), MarvelArmorItem.SuitType.THOR));
    public static final Item THOR_BOOTS = register("thor_boots",
            new MarvelArmorItem(MarvelArmorMaterials.THOR, EquipmentType.BOOTS,
                    new Item.Settings().maxCount(1), MarvelArmorItem.SuitType.THOR));

    // ========== BLACK PANTHER ==========
    public static final Item BLACK_PANTHER_HELMET = register("black_panther_helmet",
            new MarvelArmorItem(MarvelArmorMaterials.BLACK_PANTHER, EquipmentType.HELMET,
                    new Item.Settings().maxCount(1), MarvelArmorItem.SuitType.BLACK_PANTHER));
    public static final Item BLACK_PANTHER_CHESTPLATE = register("black_panther_chestplate",
            new MarvelArmorItem(MarvelArmorMaterials.BLACK_PANTHER, EquipmentType.CHESTPLATE,
                    new Item.Settings().maxCount(1), MarvelArmorItem.SuitType.BLACK_PANTHER));
    public static final Item BLACK_PANTHER_LEGGINGS = register("black_panther_leggings",
            new MarvelArmorItem(MarvelArmorMaterials.BLACK_PANTHER, EquipmentType.LEGGINGS,
                    new Item.Settings().maxCount(1), MarvelArmorItem.SuitType.BLACK_PANTHER));
    public static final Item BLACK_PANTHER_BOOTS = register("black_panther_boots",
            new MarvelArmorItem(MarvelArmorMaterials.BLACK_PANTHER, EquipmentType.BOOTS,
                    new Item.Settings().maxCount(1), MarvelArmorItem.SuitType.BLACK_PANTHER));

    // ========== CAPTAIN AMERICA ==========
    public static final Item CAPTAIN_AMERICA_HELMET = register("captain_america_helmet",
            new MarvelArmorItem(MarvelArmorMaterials.CAPTAIN_AMERICA, EquipmentType.HELMET,
                    new Item.Settings().maxCount(1), MarvelArmorItem.SuitType.CAPTAIN_AMERICA));
    public static final Item CAPTAIN_AMERICA_CHESTPLATE = register("captain_america_chestplate",
            new MarvelArmorItem(MarvelArmorMaterials.CAPTAIN_AMERICA, EquipmentType.CHESTPLATE,
                    new Item.Settings().maxCount(1), MarvelArmorItem.SuitType.CAPTAIN_AMERICA));
    public static final Item CAPTAIN_AMERICA_LEGGINGS = register("captain_america_leggings",
            new MarvelArmorItem(MarvelArmorMaterials.CAPTAIN_AMERICA, EquipmentType.LEGGINGS,
                    new Item.Settings().maxCount(1), MarvelArmorItem.SuitType.CAPTAIN_AMERICA));
    public static final Item CAPTAIN_AMERICA_BOOTS = register("captain_america_boots",
            new MarvelArmorItem(MarvelArmorMaterials.CAPTAIN_AMERICA, EquipmentType.BOOTS,
                    new Item.Settings().maxCount(1), MarvelArmorItem.SuitType.CAPTAIN_AMERICA));

    // ========== INFINITY GAUNTLET ==========
    public static final Item INFINITY_GAUNTLET_HELMET = register("infinity_gauntlet_helmet",
            new MarvelArmorItem(MarvelArmorMaterials.INFINITY_GAUNTLET, EquipmentType.HELMET,
                    new Item.Settings().maxCount(1).fireproof(), MarvelArmorItem.SuitType.INFINITY_GAUNTLET));
    public static final Item INFINITY_GAUNTLET_CHESTPLATE = register("infinity_gauntlet_chestplate",
            new MarvelArmorItem(MarvelArmorMaterials.INFINITY_GAUNTLET, EquipmentType.CHESTPLATE,
                    new Item.Settings().maxCount(1).fireproof(), MarvelArmorItem.SuitType.INFINITY_GAUNTLET));
    public static final Item INFINITY_GAUNTLET_LEGGINGS = register("infinity_gauntlet_leggings",
            new MarvelArmorItem(MarvelArmorMaterials.INFINITY_GAUNTLET, EquipmentType.LEGGINGS,
                    new Item.Settings().maxCount(1).fireproof(), MarvelArmorItem.SuitType.INFINITY_GAUNTLET));
    public static final Item INFINITY_GAUNTLET_BOOTS = register("infinity_gauntlet_boots",
            new MarvelArmorItem(MarvelArmorMaterials.INFINITY_GAUNTLET, EquipmentType.BOOTS,
                    new Item.Settings().maxCount(1).fireproof(), MarvelArmorItem.SuitType.INFINITY_GAUNTLET));

    private static Item register(String name, Item item) {
        return Registry.register(Registries.ITEM, Identifier.of(MarvelMod.MOD_ID, name), item);
    }

    public static void register() {
        // Add to combat item group
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            entries.add(IRON_MAN_HELMET);
            entries.add(IRON_MAN_CHESTPLATE);
            entries.add(IRON_MAN_LEGGINGS);
            entries.add(IRON_MAN_BOOTS);

            entries.add(SPIDER_MAN_HELMET);
            entries.add(SPIDER_MAN_CHESTPLATE);
            entries.add(SPIDER_MAN_LEGGINGS);
            entries.add(SPIDER_MAN_BOOTS);

            entries.add(THOR_HELMET);
            entries.add(THOR_CHESTPLATE);
            entries.add(THOR_LEGGINGS);
            entries.add(THOR_BOOTS);

            entries.add(BLACK_PANTHER_HELMET);
            entries.add(BLACK_PANTHER_CHESTPLATE);
            entries.add(BLACK_PANTHER_LEGGINGS);
            entries.add(BLACK_PANTHER_BOOTS);

            entries.add(CAPTAIN_AMERICA_HELMET);
            entries.add(CAPTAIN_AMERICA_CHESTPLATE);
            entries.add(CAPTAIN_AMERICA_LEGGINGS);
            entries.add(CAPTAIN_AMERICA_BOOTS);

            entries.add(INFINITY_GAUNTLET_HELMET);
            entries.add(INFINITY_GAUNTLET_CHESTPLATE);
            entries.add(INFINITY_GAUNTLET_LEGGINGS);
            entries.add(INFINITY_GAUNTLET_BOOTS);
        });
    }
}
