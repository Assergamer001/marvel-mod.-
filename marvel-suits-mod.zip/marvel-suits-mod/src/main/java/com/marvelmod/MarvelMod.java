package com.marvelmod;

import com.marvelmod.armor.MarvelArmorMaterials;
import com.marvelmod.item.MarvelItems;
import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MarvelMod implements ModInitializer {

    public static final String MOD_ID = "marvelmod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing Marvel Suits Mod!");
        MarvelArmorMaterials.register();
        MarvelItems.register();
        LOGGER.info("Marvel Suits Mod loaded successfully!");
    }
}
